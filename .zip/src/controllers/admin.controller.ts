import { type Request, type Response } from 'express';
import { StatusCodes } from 'http-status-codes';

import { type AdminId, type AdminRole, type CreateAdminInput } from '../models/admin.model';
import {
  createAdmin as createAdminService,
  forgotAdminPassword as forgotAdminPasswordService,
  getAdminById as getAdminByIdService,
  listAdmins as listAdminsService,
  loginAdmin as loginAdminService,
  logoutAdmin as logoutAdminService,
  refreshAdminAccessToken,
  resetAdminPassword as resetAdminPasswordService,
  updateAdmin as updateAdminService,
  updateAdminStatus as updateAdminStatusService,
} from '../services/admin.service';
import { SUCCESS_MESSAGES } from '../shared/success-messages';
import {
  type LoginAdminInput,
  type UpdateAdminInput,
  type UpdateAdminParams,
  type UpdateAdminStatusInput,
} from '../types/admin.types';
import { createResponseError, createSuccessResponse } from '../utils/app-response';
import { asyncHandler } from '../utils/async-handler';

const getAdmins = asyncHandler(
  async (
    req: Request<unknown, unknown, unknown, Record<string, string>>,
    res: Response,
  ): Promise<void> => {
    const { limit, offset, search, sortBy, sortDir } = req.query as unknown as {
      limit?: string;
      offset?: string;
      search?: string;
      sortBy?: string;
      sortDir?: string;
    };

    const DEFAULT_LIMIT = 20;
    const limitNumber = limit ? Number(limit) : DEFAULT_LIMIT;
    const offsetNumber = offset ? Number(offset) : 0;

    const { items, total } = await listAdminsService({
      limit: limitNumber,
      offset: offsetNumber,
      search,
      sortBy,
      sortDir: sortDir === 'asc' ? 'asc' : 'desc',
    });

    const currentPageNumber = Math.floor(offsetNumber / limitNumber) + 1;

    res.status(StatusCodes.OK).json(
      createSuccessResponse({
        statusCode: StatusCodes.OK,
        message: SUCCESS_MESSAGES.common.success,
        data: {
          items,
          pagination: {
            limit: limitNumber,
            offset: offsetNumber,
            total,
            currentPageNumber,
            sortBy: sortBy ?? 'createdAt',
            sortDir: sortDir === 'asc' ? 'asc' : 'desc',
          },
        },
      }),
    );
  },
);

const getAdminById = asyncHandler(
  async (req: Request<{ id: string }>, res: Response): Promise<void> => {
    const { id } = req.params;

    const admin = await getAdminByIdService(id);

    if (!admin) {
      res.status(StatusCodes.NOT_FOUND).json(
        createSuccessResponse({
          statusCode: StatusCodes.NOT_FOUND,
          message: 'Admin not found',
          data: null,
        }),
      );
      return;
    }

    const {
      password: _password,
      passwordResetToken: _passwordResetToken,
      twoFactorSecret: _twoFactorSecret,
      ...safeAdmin
    } = admin;

    res.status(StatusCodes.OK).json(
      createSuccessResponse({
        statusCode: StatusCodes.OK,
        message: SUCCESS_MESSAGES.common.success,
        data: safeAdmin,
      }),
    );
  },
);

const createAdmin = asyncHandler(
  async (req: Request<unknown, unknown, CreateAdminInput>, res: Response): Promise<void> => {
    const actingAdminId = (req as unknown as { id?: string }).id ?? null;
    const actingAdminType = (req as unknown as { adminType?: AdminRole }).adminType ?? null;

    const admin = await createAdminService(req.body, actingAdminId, actingAdminType);
    const {
      password: _password,
      passwordResetToken: _passwordResetToken,
      twoFactorSecret: _twoFactorSecret,
      ...safeAdmin
    } = admin;

    res.status(StatusCodes.CREATED).json({
      ...createSuccessResponse({
        statusCode: StatusCodes.CREATED,
        message: SUCCESS_MESSAGES.common.success,
        data: safeAdmin,
      }),
    });
  },
);

const loginAdmin = asyncHandler(
  async (req: Request<unknown, unknown, LoginAdminInput>, res: Response): Promise<void> => {
    const loginResponse = await loginAdminService({
      ...req.body,
      loginIp: req.ip,
    });

    res.status(StatusCodes.OK).json(
      createSuccessResponse({
        statusCode: StatusCodes.OK,
        message: SUCCESS_MESSAGES.common.success,
        data: loginResponse,
      }),
    );
  },
);

const updateAdmin = asyncHandler(
  async (
    req: Request<UpdateAdminParams, unknown, UpdateAdminInput>,
    res: Response,
  ): Promise<void> => {
    // get the id and role attached by authentication middleware (the acting admin)
    const actingAdminId = (req as unknown as { id?: string }).id ?? null;
    const actingAdminType = (req as unknown as { adminType?: string }).adminType ?? null;

    // Only a superAdmin may change an admin's role — block everyone else here
    if (req.body.role && actingAdminType !== 'superAdmin') {
      throw createResponseError({
        statusCode: StatusCodes.FORBIDDEN,
        message: "Only a superAdmin can change an admin's role",
      });
    }

    // ensure updatedBy is set to the acting admin id (do not trust client-provided value)
    const inputWithUpdatedBy: UpdateAdminInput = {
      ...req.body,
      // cast here because UpdateAdminInput.updatedBy is a UUID literal type
      updatedBy: actingAdminId as unknown as UpdateAdminInput['updatedBy'],
    };

    const admin = await updateAdminService(req.params.id, inputWithUpdatedBy);
    const {
      password: _password,
      passwordResetToken: _passwordResetToken,
      twoFactorSecret: _twoFactorSecret,
      ...safeAdmin
    } = admin;

    res.status(StatusCodes.OK).json(
      createSuccessResponse({
        statusCode: StatusCodes.OK,
        message: SUCCESS_MESSAGES.common.success,
        data: safeAdmin,
      }),
    );
  },
);

const updateAdminStatus = asyncHandler(
  async (
    req: Request<UpdateAdminParams, unknown, UpdateAdminStatusInput>,
    res: Response,
  ): Promise<void> => {
    const actingAdminId = (req as unknown as { id?: string }).id ?? null;

    const admin = await updateAdminStatusService(
      req.params.id,
      req.body.status,
      actingAdminId as unknown as AdminId | null,
    );
    const {
      password: _password,
      passwordResetToken: _passwordResetToken,
      twoFactorSecret: _twoFactorSecret,
      ...safeAdmin
    } = admin;

    res.status(StatusCodes.OK).json(
      createSuccessResponse({
        statusCode: StatusCodes.OK,
        message: SUCCESS_MESSAGES.common.success,
        data: safeAdmin,
      }),
    );
  },
);
const refreshToken = asyncHandler(
  async (
    req: Request<unknown, unknown, { refreshToken: string }>,
    res: Response,
  ): Promise<void> => {
    const result = await refreshAdminAccessToken(req.body.refreshToken);
    res.status(StatusCodes.OK).json(
      createSuccessResponse({
        statusCode: StatusCodes.OK,
        message: SUCCESS_MESSAGES.common.success,
        data: result,
      }),
    );
  },
);
const logoutAdmin = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const adminId = (req as unknown as { id?: string }).id;

  if (adminId) {
    await logoutAdminService(adminId as unknown as AdminId);
  }

  res.status(StatusCodes.OK).json(
    createSuccessResponse({
      statusCode: StatusCodes.OK,
      message: SUCCESS_MESSAGES.common.success,
      data: null,
    }),
  );
});

const forgotPassword = asyncHandler(
  async (req: Request<unknown, unknown, { email: string }>, res: Response): Promise<void> => {
    await forgotAdminPasswordService(req.body.email);

    res.status(StatusCodes.OK).json(
      createSuccessResponse({
        statusCode: StatusCodes.OK,
        message: 'If that email exists, a reset code has been sent.',
        data: null,
      }),
    );
  },
);

const resetPassword = asyncHandler(
  async (
    req: Request<unknown, unknown, { email: string; code: string; newPassword: string }>,
    res: Response,
  ): Promise<void> => {
    await resetAdminPasswordService(req.body.email, req.body.code, req.body.newPassword);

    res.status(StatusCodes.OK).json(
      createSuccessResponse({
        statusCode: StatusCodes.OK,
        message: SUCCESS_MESSAGES.common.success,
        data: null,
      }),
    );
  },
);

export {
  createAdmin,
  forgotPassword,
  getAdminById,
  getAdmins,
  loginAdmin,
  logoutAdmin,
  refreshToken,
  resetPassword,
  updateAdmin,
  updateAdminStatus,
};
